from pymongo.mongo_client import MongoClient

uri = "mongodb+srv://testing:testing1234@cluster0.lsonghv.mongodb.net/?retryWrites=true&w=majority"

# Create a new client and connect to the server
client = MongoClient(uri)
db = client["DineNoSore"]

# Get a reference to the collection
collection = db["Collection1"]

for x in collection.find({},{ "name": "Hello World!" }):
  print(x)