from flask import Flask
import logging
import socket
from pymongo.mongo_client import MongoClient
from flask import Flask, request, jsonify
import re
import pymongo

logger = logging.getLogger(__name__)
app = Flask(__name__)

# connect mongodb

uri = "mongodb+srv://testing:testing1234@cluster0.lsonghv.mongodb.net/?retryWrites=true&w=majority"
client = MongoClient(uri)
db = client["DineNoSore"]

@app.route("/")
def hello_world():
    return "Hello, World!"

@app.route("/channels", methods=['GET'])
def getAllChatChannels():
    collection = db["Channels"]
    # Retrieve all documents from the collection
    all_documents = collection.find()

    # Convert the documents to a list of dictionaries
    documents_list = []
    for document in all_documents:
        print(document)
        document.pop('_id', None)
        documents_list.append(document)

    # Return the documents as JSON
    return jsonify(documents_list)

@app.route("/restaurantbrief", methods=["GET"])
def getRestaurantBrief():
    collection = db["RestaurantBrief"]
    keyword = request.args.get("keyword", "")
    documents_list = []
    print(keyword)
    # Perform the case-insensitive find operation
    pattern = re.compile(keyword, re.IGNORECASE)
    if (len(keyword)>0):
        results = collection.find({"$or": [{"restaurantName": {"$regex": pattern}}, {"district": {"$regex": pattern}}, {"cuisine": {"$regex": pattern}}]})

        # Iterate over the results
        for document in results:
            document.pop('_id', None)
            documents_list.append(document)
    print(documents_list)
    return jsonify(documents_list)

@app.route("/diningroom", methods=["GET"])
def getDiningRoom():
    collection = db["DiningRoom"]
    roomNumber = request.args.get("roomnumber", "")
    print(roomNumber)
    pattern = re.compile('.*' + re.escape(roomNumber) + '.*')
    result = None
    if (len(roomNumber)>0):
        result = collection.find_one({"roomNumber": {'$regex': pattern}})
        result.pop('_id', None)
    return jsonify(result)

@app.route("/trending", methods=["GET"])
def getTrending():
    collection = db["RestaurantBrief"]
    # Field to sort by
    sort_field = 'date'

    # Sort in ascending order (1) or descending order (-1)
    sort_order = pymongo.ASCENDING

    # Find and sort documents, limit to first five
    documents = collection.find().sort(sort_field, sort_order).limit(2)
    documents_list = []
    for document in documents:
        document.pop('_id', None)
        documents_list.append(document)
    return jsonify(documents_list)


logger = logging.getLogger()
handler = logging.StreamHandler()
formatter = logging.Formatter(
    '%(asctime)s %(name)-12s %(levelname)-8s %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

if __name__ == "__main__":
    logging.info("Starting application ...")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 8080))
    port = sock.getsockname()[1]
    sock.close()
    app.run(port=port)