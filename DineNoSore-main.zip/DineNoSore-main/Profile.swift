//
//  Profile.swift
//  DineNoSore
//
//  Created by Fu Kin Hang on 3/11/2023.
//

import Foundation


struct Profile {
    var username: String
    var age: Int
    var userPhoto = "user4"
    var gender: String

    static let `default` = Profile(username: "Peter", age: 19, gender: "Male")


    enum PreferredCusine: String, CaseIterable, Identifiable {
        case japanese = "Japanese"
        case korean = "Korean"
        case chinese = "Chinese"
        case french = "French"
        case italian = "Italian"
        case thai = "Thai"
        case indian = "Indian"
        
        var id: String { rawValue }
    }
}


