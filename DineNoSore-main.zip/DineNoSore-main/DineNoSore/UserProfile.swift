//
//  UserProfile.swift
//  DineNoSore
//
//  Created by Fu Kin Hang on 3/11/2023.
//

import SwiftUI


struct UserProfile: View {
    @Environment(\.editMode) var editMode
    var profile: Profile
    var body: some View {
        VStack {
            ZStack(alignment: .topTrailing) {
                Image(profile.userPhoto)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                EditButton()
                    .padding()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                

                
            }
            
            
            
            
            VStack(alignment: .leading) {
                Text(profile.username)
                    .font(.title)
                
                HStack {
                    Text("\(profile.age),  \(profile.gender)")
                        .font(.subheadline)
                    Spacer()
                    Text("Middle East")
                        .font(.subheadline)
                }
                .padding(.bottom, 10)
                
                Text("Preferred Cuisines")
                    .font(.title2)
                HStack {
                    Text("Japanese")
                        .font(.subheadline)
                    
                    Text("Middle East")
                        .font(.subheadline)
                }
                .padding(.bottom, 10)
                
                Text("Dietary Restrictions")
                    .font(.title2)
                HStack {
                    Text("Japanese")
                        .font(.subheadline)
                    
                    Text("Middle East")
                        .font(.subheadline)
                }
                .padding(.bottom, 10)
                
                
                
                
                Text("About Edison")
                    .font(.title2)
                
                Text("Descriptive text goes here.")
            }
            .padding()
            
            
            Spacer()
        }
        .edgesIgnoringSafeArea(.top)
    }
}

#Preview {
    UserProfile(profile: Profile.default)
}
