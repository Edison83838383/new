//
//  RestaurantBrief.swift
//  DineNoSore
//
//  Created by Rain Poon on 7/11/2023.
//

import Foundation


struct RestaurantBrief: Codable {
    let restaurantName: String
    let district: String
    let distance: String
    let cuisine: String
    let photos: [String]
    let numOfStars: Int
    let rating: String
    let roomNumber: String
    let date: String
    let time: String
    let numOfJoined: Int
    let maxParti: Int
}

