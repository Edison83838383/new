//
//  ChatMessage.swift
//  DineNoSore
//
//  Created by Rain Poon on 5/11/2023.
//

import Foundation

struct ChatMessage: Identifiable {
    var id = UUID()
    let sender: String
    let message: String
    let timestamp: Date
}

