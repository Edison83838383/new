//
//  Channel.swift
//  DineNoSore
//
//  Created by Rain Poon on 6/11/2023.
//

import Foundation

struct Channel: Identifiable {
    let id = UUID()
    let imageName: String
    let restaurantName: String
    let date: String
    let roomNumber: String
}
