//
//  Message.swift
//  DineNoSore
//
//  Created by Rain Poon on 14/11/2023.
//

import Foundation

struct Message: Codable {
    let user: String
    let time: Int // unix timestamp
    let roomNumber: String
    let content: String
}
