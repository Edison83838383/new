//
//  DB.swift
//  DineNoSore
//
//  Created by Rain Poon on 4/11/2023.
//

import Foundation

struct Wrapper: Codable {
    let items: [Document]
}

struct Document: Codable {
    let _id: String
    let name: String
}
