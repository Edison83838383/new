//
//  DiningRoom.swift
//  DineNoSore
//
//  Created by Rain Poon on 13/11/2023.
//

import Foundation

struct DiningRoom: Codable {
    let restaurantName: String
    let address: String
    let numOfJoined: Int
    let maxParti: Int
    let groupDescription: String
    let roomNumber: String
    let foodPhotos: [String]
    let interiorPhotos: [String]
    let menuPhotos: [String]
    let date: String
    let time: String
}
