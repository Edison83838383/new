//
//  ChannelRow.swift
//  DineNoSore
//
//  Created by Rain Poon on 5/11/2023.
//

import SwiftUI

struct ChannelRowView: View {
    let imageName: String
    let restaurantName: String
    let date: String
    var body: some View {
        HStack {
            Image(imageName)
                .resizable()
                .frame(width: 70, height: 70)
                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                .padding()
            VStack {
                Text(restaurantName)
                    .font(.headline)
                    .fontWeight(.bold)
                    .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                Text(date)
                    .opacity(0.7)
                    .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                Spacer()
                    .frame(height: 10)
            }
            .frame(height: 70)
        }
    }
}

#Preview {
    ChannelRowView(imageName: "teawood_outside", restaurantName: "TeaWood", date: "17th Nov 2023")
}
