//
//  MapView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI
import UIKit

struct MapView: View {
    let address: String
    let maxAddressLength = 30
    
    var body: some View {
        Button(action: {
            openAppleMaps()
        }) {
            HStack {
                Image(systemName: "map.fill")
                Text(truncateAddress())
            }
            
        }
    }

    func openAppleMaps() {
        let addressEncoded = address.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        if let url = URL(string: "http://maps.apple.com/?address=" + addressEncoded) {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
            } else {
                // Handle the case where Apple Maps can't be opened (e.g., on a simulator)
                print("Apple Maps cannot be opened.")
            }
        }
    }
    
    func truncateAddress() -> String {
            if address.count > maxAddressLength {
                return String(address.prefix(maxAddressLength)) + "..."
            } else {
                return address
            }
        }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView(address: "1600 Amphitheatre Parkway, Mountain View, CA")
    }
}
