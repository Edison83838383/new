//
//  RestaurantCellView.swift
//  DineNoSore
//
//  Created by Rain Poon on 6/11/2023.
//

import SwiftUI

struct RestaurantCellView: View {
    let restaurantName: String
    let district: String
    let distance: String
    let cuisine: String
    let photos: [String]
    let numOfStars: Int
    let rating: String
    let date: String
    let time: String
    var body: some View {
        VStack(alignment: .leading) {
            Text(restaurantName)
                .font(.title3)
                .fontWeight(.bold)
//                .frame(maxWidth: UIScreen.main.bounds.width*0.9, alignment: .leading)
            Text(district+"/ "+distance+"/ "+cuisine)
            Text("\(date) \(time)")
            HStack (spacing: 4) {
                ForEach(0 ..< 5) { item in
                    Image(systemName: "star.fill")
                        .foregroundColor((item<numOfStars) ? .yellow : .gray)
                }
                Text("(\(rating))")
                    .opacity(0.5)
                    .padding(.leading, 8)
            }
            HStack {
                ForEach(photos, id: \.self) { imageName in
                    Image(imageName)
                        .resizable()
                        .aspectRatio(1, contentMode: .fit)
                        .cornerRadius(10)
                        .frame(width: 80, height: 80)
                }
            }
            
        }
        .frame(maxWidth: UIScreen.main.bounds.width*0.9, alignment: .leading)

    }
}

#Preview {
    RestaurantCellView(restaurantName: "Teawood", district: "Tsim Sha Tsui", distance: "1.2km", cuisine: "Taiwan", photos: ["teawood_outside", "teawood_food_1", "teawood_food_2"], numOfStars: 4, rating: "4.1", date: "27th Nov 2023", time: "19:30")
}
