//
//  SearchBoxView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

struct SearchBoxView: View {
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(Color(hue: 1.0, saturation: 0.012, brightness: 0.849))
                .cornerRadius(30)
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                    .padding(.leading)
                Text("Restaurants")
                    .foregroundColor(.gray)
                Spacer()
                Image(systemName: "magnifyingglass.circle.fill")
                    .resizable(resizingMode: .stretch)
                    .aspectRatio(1, contentMode: .fit)
                    .frame(height: 40)
                    .offset(x:-5)
            }
        }
        .frame(width: UIScreen.main.bounds.width*0.9, height: 50)
    }
}

struct SearchBoxView_Previews: PreviewProvider {
    static var previews: some View {
        SearchBoxView()
    }
}
