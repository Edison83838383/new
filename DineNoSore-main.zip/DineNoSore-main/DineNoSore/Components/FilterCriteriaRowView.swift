//
//  FilterCriteriaRowView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

struct FilterCriteriaRowView: View {
    
    @State private var dictionary: [String: [String]] = [
        "District": ["Central", "Causeway Bay", "Mong Kok", "Sai Wan"],
        "Cuisine": ["Chinese", "Western", "Korean"],
//        "Members": ["One", "Two", "Three", "Four", "Five"]
        "Members": ["2", "3", "4", "5+"]
    ]
    
    @State private var booleanArray: [String: [Bool]] = [:]
    
    init() {
        // Initialize booleanArray in the init method
        self._booleanArray = State(initialValue: generateBooleanArray(input: dictionary))
    }
    
    
    var body: some View {
        VStack {
            ForEach(dictionary.sorted(by: { $0.key < $1.key }), id: \.key) { (key, values) in
                ScrollView(.horizontal) {
                    HStack {
                        Text(key)
                        ForEach(0..<values.count) { value in
                            Button {
                                if var keyArray = booleanArray[key] {
                                    keyArray[value].toggle() // Toggle the boolean value
                                    booleanArray[key] = keyArray // Update the dictionary with the new value
                                }
                            } label: {
                                Text(values[value])
                                    .foregroundColor(.white)
                                    .padding(.horizontal)
                                    .padding(.vertical, 5)
                                    .background(
                                        Rectangle()
                                            .foregroundColor(booleanArray[key]?[value] == true ? .blue : .gray)
                                            .cornerRadius(20)
                                        
                                    )
                            }
                        }
                    }
                }
            }
            
        }
        .padding()
    }
    
    
}

func generateBooleanArray(input: [String: [String]]) -> [String: [Bool]] {
    var array = [String: [Bool]]()
    
    for (key, value) in input {
        var rowArray = [Bool]()
        
        for _ in value {
            rowArray.append(false)
        }
        
        array[key] = rowArray
    }
    
    return array
}



struct FilterCriteriaRowView_Previews: PreviewProvider {
    static var previews: some View {
        FilterCriteriaRowView()
    }
}
