//
//  TrendingSnapshot.swift
//  DineNoSore
//
//  Created by Rain Poon on 13/11/2023.
//

import SwiftUI

struct TrendingSnapshot: View {
    let brief: RestaurantBrief
    var body: some View {
        ZStack {
            Image(brief.photos[0])
                .resizable()
                .aspectRatio(1, contentMode: .fit)
                .cornerRadius(10)
                .frame(width: 200, height: 200)
            VStack {
                HStack {
                    Image(systemName: "flame.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.red)
                        .frame(width: 30)
                    Spacer()
                    Text("\(String(brief.numOfJoined))/\(String(brief.maxParti))")
                        .foregroundColor(.white)
                        .padding(7.0)
                        .background(
                            Circle()
                        )
                }
                .padding(5.0)
                Spacer()
                VStack(alignment: .leading) {
                    Text(brief.restaurantName)
                        .font(.title3)
                        .fontWeight(.bold)
                    HStack {
                        Image(systemName: "location.circle.fill")
                        Text(brief.district)
                    }
                    Text("\(brief.date) \(brief.time)")
                }
                .padding(5.0)
                .frame(maxWidth: 200, alignment: .leading)
                .background(
                    Color.white
                        .opacity(0.7)
                )
            }
        }
        .frame(maxWidth: 200, maxHeight: 200)
    }
}

struct TrendingSnapshot_Previews: PreviewProvider {
    static var previews: some View {
        let b = RestaurantBrief(restaurantName: "Teawood", district: "Tsim Sha Tsui", distance: "1.2km", cuisine: "Taiwan", photos: ["teawood_outside", "teawood_food_1", "teawood_food_2"], numOfStars: 4, rating: "4.1", roomNumber: "PR3789", date: "27th Nov 2023", time: "19:30", numOfJoined: 3, maxParti: 5)
        TrendingSnapshot(brief: b)
    }
}
