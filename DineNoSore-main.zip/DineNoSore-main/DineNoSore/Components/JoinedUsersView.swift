//
//  JoinedUsersView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

struct JoinedUsersView: View {
    // existing users in the room
    var users: [String]
    // number of existing users in the room
    @State var count: Int
    // maximum number of users can join the room
    let maxCount: Int
    // user picture
    let userPic: String
    
    init(users: [String], count: Int, maxCount: Int, userPic: String) {
        self.users = users
        self._count = State(initialValue: count)
        self.maxCount = maxCount
        self.userPic = userPic
    }
    
    @State private var isAdded: Bool = false
    
    var body: some View {
        HStack {
            ForEach(0..<count, id: \.self) { index in
                Image(users[index])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 40)
                    .cornerRadius(40/2)
            }
            if (isAdded) {
                Image(userPic)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 40)
                    .cornerRadius(40/2)
            }
            Button(action: {
                isAdded.toggle()
            }) {
                if (!isAdded) {
                    Image(systemName: "plus")
                } else {
                    Image(systemName: "minus")
                }
                
            }
        }
    }
}

struct JoinedUsersView_Previews: PreviewProvider {
    static var previews: some View {
        JoinedUsersView(users: ["user2", "user3", "user4", "user5", "user6"], count: 3, maxCount: 6, userPic: "user7")
    }
}

