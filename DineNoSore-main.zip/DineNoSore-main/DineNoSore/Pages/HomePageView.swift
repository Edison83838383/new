//
//  HomePageView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

struct HomePageView: View {
    @State private var briefs: [RestaurantBrief] = []
    @State private var isPresentingFullView = false
    @State private var rooms: DiningRoom? = nil
    
    func fetchDiningRoom(roomNumber: String) {
        Task {
            rooms = await getDiningRoom(roomNumber: roomNumber)
        }
    }
    
    func fetchData() async {
        briefs = await getTrending()
        print("fetched")
    }
    
    var body: some View {
            NavigationView() {
                    VStack {
                        ZStack {
                            Rectangle()
                                .fill(Color(red: 0x00/0xff, green: 0x5b/0xff, blue: 0x23/0xff))
                                .edgesIgnoringSafeArea(.all)
                                .frame(height: 50)
                                .shadow(radius: 2)
                            HStack {
                                Image(systemName: "fork.knife.circle.fill")
                                    .foregroundColor(.white)
                                Text("DinoNoSore")
                                    .foregroundColor(.white)
                                    .font(.title2)
                                    .fontWeight(.bold)
                            }
                            
                        }
                        VStack {
                            NavigationLink(destination: SearchingView()) {
                                SearchBoxView()
                                    .padding()
                            }
                        }
                        Text("Trending Dining Rooms")
                            .font(.title2)
                            .fontWeight(.bold)
                            .frame(maxWidth: UIScreen.main.bounds.width*0.9, alignment: .leading)
                        ScrollView(.horizontal) {
                            HStack(spacing: 20) {
                                ForEach(0..<briefs.count, id: \.self) {
                                    index in
                                    TrendingSnapshot(brief: briefs[index])
                                        .onTapGesture {
                                            fetchDiningRoom(roomNumber: briefs[index].roomNumber)
                                            isPresentingFullView = true
                                        }
                                        .fullScreenCover(isPresented: $isPresentingFullView) {
                                            if let diningRoom = rooms {
                                                FullView2(diningRoom: diningRoom, dismissAction: {
                                                    isPresentingFullView = false
                                                })
                                                .transition(.move(edge: .leading))
                                            } else {
                                                // You can show a loading view or handle the case when the dining room data is not available yet
                                                Text("Loading...")
                                            }
                                        }
                                }
                            }
                        }
                        .padding()
                        
                        Spacer()
                    }
                    .onAppear {
                        Task {
                            await fetchData()
                        }
                    }
                
            }
            
    }
}

struct HomePageView_Previews: PreviewProvider {
    static var previews: some View {
        HomePageView()
    }
}
