//
//  ChatChannelsView.swift
//  DineNoSore
//
//  Created by Rain Poon on 6/11/2023.
//

import SwiftUI

struct ChatChannelsView: View {
    @State private var channels: [Channel] = []
    var body: some View {
        NavigationView {
            VStack {
                Text("Chats")
                    .font(.title3)
                    .fontWeight(.bold)
                Divider()
                
                ScrollView(.vertical) {
                    VStack {
                        ForEach(channels) {
                            channel in
                            NavigationLink(destination: ChannelPageView()) {
                                ChannelRowView(imageName: channel.imageName, restaurantName: channel.restaurantName, date: channel.date)
                            }
                            
                            Divider()
                        }
                    }
                }
            }
            .onAppear {
                getChannels { channels in
                    if let channels = channels {
                        self.channels = channels
                        print("fetched")
                    } else {
                        print("No channels available")
                    }
                }
            }
        }
        
    }
}

#Preview {
    ChatChannelsView()
}
