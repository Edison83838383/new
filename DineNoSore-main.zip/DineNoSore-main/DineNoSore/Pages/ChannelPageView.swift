//
//  ChannelPageView.swift
//  DineNoSore
//
//  Created by Rain Poon on 6/11/2023.
//

import SwiftUI

struct ChannelPageView: View {
    @State private var chatMessages: [ChatMessage] = []
    @State private var newMessage: String = ""
    
    var body: some View {
        VStack {
            ScrollView {
                ForEach(chatMessages) { message in
                    let isLeft = message.sender != "Me"
                    VStack {
                        Text(message.sender)
                            .fontWeight(.bold)
                            .frame(maxWidth: UIScreen.main.bounds.width*0.9, alignment: isLeft ? .leading : .trailing)
                            .offset(y:7)
                        Text(message.message)
                            .padding()
                            .background(
                                Rectangle()
                                    .foregroundColor(isLeft ? Color(.lightGray) : .green)
                                    .cornerRadius(20)
                            )
                            .frame(maxWidth: UIScreen.main.bounds.width*0.95, alignment: isLeft ? .leading : .trailing)
                    }
                }
            }
            
            HStack {
                TextField("Enter message", text: $newMessage)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button(action: sendMessage) {
                    Text("Send")
                }
                .padding(8)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .padding()
        }
        .onAppear {
            loadChats()
        }
    }
    
    func loadChats() {
        let message1 = ChatMessage(sender: "John", message: "Hello", timestamp: Date())
        let message2 = ChatMessage(sender: "Jane", message: "Hi there", timestamp: Date())
        let message3 = ChatMessage(sender: "John", message: "How are you? How are you? How are you? How are you? How are you? How are you? How are you? How are you? How are you? How are you? How are you? How are you?", timestamp: Date())
        let message4 = ChatMessage(sender: "Me", message: "Hi all!", timestamp: Date())
        chatMessages.append(message1)
        chatMessages.append(message2)
        chatMessages.append(message3)
        chatMessages.append(message4)
    }
    
    func sendMessage() {
        if (!newMessage.isEmpty) {
            let newChatMessage = ChatMessage(sender: "Me", message: newMessage, timestamp: Date())
            chatMessages.append(newChatMessage)
            newMessage = "" // Clear the text field after sending the message
        }
    }
}

#Preview {
    ChannelPageView()
}
