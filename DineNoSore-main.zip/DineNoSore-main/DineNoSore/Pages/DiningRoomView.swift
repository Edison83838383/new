//
//  DiningRoomView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

struct DiningRoomView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    // variables
    let restaurantName: String
    let address: String
    let numOfJoined: Int
    let maxParti: Int
    let groupDescription: String
    let roomNumber: String
    let foodPhotos: [String]
    let interiorPhotos: [String]
    let menuPhotos: [String]
    
    enum PhotoCategory: String, CaseIterable, Identifiable {
        case food = "Food"
        case interior = "Interior"
        case menu = "Menu"
        var id: Self { self }
    }
    
    @State private var selectedPhotoCategory: PhotoCategory = .food
    @State private var isShowingFullImage = false
    @State private var selectedImageName: String = ""
    
    var body: some View {
        ScrollView(.vertical) {
            VStack(spacing: 10) {
                HStack {
                    Button {
                        self.presentationMode.wrappedValue.dismiss()
                    } label: {
                        Image(systemName: "chevron.backward")
                            .padding(.trailing)
                        
                    }
                    Text(roomNumber)
                    Spacer()
                }
                .padding([.top, .trailing])
                Text(restaurantName)
                    .font(.title)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding([.top, .bottom, .trailing])
                MapView(address: address)
                    .frame(maxWidth: .infinity, alignment: .leading)
                HStack {
                    Image(systemName: "calendar")
                    Text("27th Nov 2023")
                    Spacer()
                }
                HStack {
                    Image(systemName: "clock.fill")
                    Text("19:30")
                    Spacer()
                }
                HStack {
                    Image(systemName: "person.fill")
                    Text(String(numOfJoined)+" / "+String(maxParti))
                    Spacer()
                }
                Text("Group Description: "+groupDescription)
                    .multilineTextAlignment(.leading)
                    .opacity(0.5)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("Featured Photos")
                    .font(.title3)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Picker("PhotoCategory", selection: $selectedPhotoCategory) {
                    ForEach(PhotoCategory.allCases) { category in
                        Text(category.rawValue)
                    }
                }
                .pickerStyle(.segmented)
                photoScrollView(photoCategory: selectedPhotoCategory)
                Text("Members")
                    .font(.title3)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Divider()
                JoinedUsersView(users: ["user2", "user3", "user4", "user5", "user6"], count: 3, maxCount: 6, userPic: "user7")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(width: UIScreen.main.bounds.width*0.9)
        }
        .navigationBarBackButtonHidden()
    }
    
    func photoScrollView(photoCategory: PhotoCategory) -> AnyView {
        let photos: [String]
        switch photoCategory {
        case .food:
            photos = foodPhotos
        case .interior:
            photos = interiorPhotos
        case .menu:
            photos = menuPhotos
        }
        return AnyView(
            ScrollView(.horizontal) {
                HStack {
                    ForEach(photos, id: \.self) {item in
                        Image(item)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 200, height: 200) // Set the desired aspect ratio here
                            .clipped() // Apply the clipping to crop the image
                            .onTapGesture {
                                // When tapped, show the full image
                                isShowingFullImage = true
                                selectedImageName = item
                            }
                            .sheet(isPresented: $isShowingFullImage) {
                                // Show the full image in a sheet
                                FullImageView(imageName: selectedImageName)
                            }
                    }
                }
            }
        )
    }
}
struct FullImageView: View {
    let imageName: String
    var body: some View {
        // Display the full image
        Image(imageName)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
    }
}

struct DiningRoomView_Previews: PreviewProvider {
    static var previews: some View {
        DiningRoomView(restaurantName: "TeaWood", address: "63 Nathan Rd, Tsim Sha Tsui, Hong Kong", numOfJoined: 3, maxParti: 5, groupDescription: "Welcome all meat lovers! We love to explore restaurants with excellent meat dishes!", roomNumber: "#PR3789", foodPhotos: ["teawood_food_1", "teawood_food_2"], interiorPhotos: ["teawood_interior_1"], menuPhotos: ["teawood_menu_1"])
    }
}
