//
//  Testing.swift
//  DineNoSore
//
//  Created by Rain Poon on 13/11/2023.
//

import SwiftUI

struct Testing: View {
    @State private var isPresentingFullView = false
    @State private var rooms: DiningRoom? = nil
    
    func fetchData(roomNumber: String) {
        Task {
            rooms = await getDiningRoom(roomNumber: roomNumber)
        }
    }
    
    var body: some View {
        Button("Present Full View") {
            fetchData(roomNumber: "PR3789")
            isPresentingFullView = true
        }
        .fullScreenCover(isPresented: $isPresentingFullView) {
            if let diningRoom = rooms {
                FullView2(diningRoom: diningRoom, dismissAction: {
                    isPresentingFullView = false
                })
                .transition(.move(edge: .leading))
            } else {
                // You can show a loading view or handle the case when the dining room data is not available yet
                Text("Loading...")
            }
        }
        
    }
}

struct FullView: View {
    @Environment(\.presentationMode) var presentationMode
    let diningRoom: DiningRoom
    let dismissAction: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Text("Full View")
                    .foregroundColor(.white)
                    .font(.largeTitle)
                
                Text("Room Number: \(diningRoom.roomNumber)")
                    .foregroundColor(.white)
                
                // Show other details of the dining room here
                
                Button("Dismiss") {
                    dismissAction()
                }
                .padding()
            }
        }
    }
}

struct FullView2: View {
    @Environment(\.presentationMode) var presentationMode
    let diningRoom: DiningRoom
    let dismissAction: () -> Void
    
    enum PhotoCategory: String, CaseIterable, Identifiable {
        case food = "Food"
        case interior = "Interior"
        case menu = "Menu"
        var id: Self { self }
    }
    
    @State private var selectedPhotoCategory: PhotoCategory = .food
    @State private var isShowingFullImage = false
    @State private var selectedImageName: String = ""
    
    var body: some View {
        ScrollView(.vertical) {
            VStack(spacing: 10) {
                HStack {
                    Button {
                        dismissAction()
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .rotationEffect(.degrees(45))
                            .foregroundColor(.black)
                            .padding(.trailing)
                        
                    }
                    Text("#\(diningRoom.roomNumber)")
                    Spacer()
                }
                .padding([.top, .trailing])
                Text(diningRoom.restaurantName)
                    .font(.title)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding([.top, .bottom, .trailing])
                MapView(address: diningRoom.address)
                    .frame(maxWidth: .infinity, alignment: .leading)
                HStack {
                    Image(systemName: "calendar")
                    Text(diningRoom.date)
                    Spacer()
                }
                HStack {
                    Image(systemName: "clock.fill")
                    Text(diningRoom.time)
                    Spacer()
                }
                HStack {
                    Image(systemName: "person.fill")
                    Text(String(diningRoom.numOfJoined)+" / "+String(diningRoom.maxParti))
                    Spacer()
                }
                Text("Group Description: "+diningRoom.groupDescription)
                    .multilineTextAlignment(.leading)
                    .opacity(0.5)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("Featured Photos")
                    .font(.title3)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Picker("PhotoCategory", selection: $selectedPhotoCategory) {
                    ForEach(PhotoCategory.allCases) { category in
                        Text(category.rawValue)
                    }
                }
                .pickerStyle(.segmented)
                photoScrollView(photoCategory: selectedPhotoCategory)
                Text("Members")
                    .font(.title3)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Divider()
                JoinedUsersView(users: ["user2", "user3", "user4", "user5", "user6"], count: 3, maxCount: 6, userPic: "user7")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(width: UIScreen.main.bounds.width*0.9)
        }
        .navigationBarBackButtonHidden()
    }
    
    func photoScrollView(photoCategory: PhotoCategory) -> AnyView {
        let photos: [String]
        switch photoCategory {
        case .food:
            photos = diningRoom.foodPhotos
        case .interior:
            photos = diningRoom.interiorPhotos
        case .menu:
            photos = diningRoom.menuPhotos
        }
        return AnyView(
            ScrollView(.horizontal) {
                HStack {
                    ForEach(photos, id: \.self) {item in
                        Image(item)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 200, height: 200) // Set the desired aspect ratio here
                            .clipped() // Apply the clipping to crop the image
                            .onTapGesture {
                                // When tapped, show the full image
                                isShowingFullImage = true
                                selectedImageName = item
                            }
                            .sheet(isPresented: $isShowingFullImage) {
                                // Show the full image in a sheet
                                FullImageView(imageName: selectedImageName)
                            }
                    }
                }
            }
        )
    }
}


#Preview {
    Testing()
}
