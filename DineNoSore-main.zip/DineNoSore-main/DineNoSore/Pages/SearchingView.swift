//
//  SearchingView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

struct SearchingView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State private var searchText = ""
    @State private var isShowSearchResults: Bool = false
    @State private var briefs: [RestaurantBrief] = []
    @State private var isPresentingFullView = false
    @State private var rooms: DiningRoom? = nil
    
    func fetchData(keyword: String) async {
        briefs = await getRestaurantBrief(keyword: keyword)
        print("fetched")
    }
    
    func fetchDiningRoom(roomNumber: String) {
        Task {
            rooms = await getDiningRoom(roomNumber: roomNumber)
        }
    }
    
    var body: some View {
        VStack {
            HStack {
                Button {
                    self.presentationMode.wrappedValue.dismiss()
                } label: {
                    Image(systemName: "chevron.backward")
                        .padding([.top, .bottom, .trailing])
                }
                VStack {
                    TextField("Restaurants", text: $searchText)
                        .onSubmit {
                            Task {
                                await fetchData(keyword: searchText)
                            }
                            
                            isShowSearchResults = true
                        }
                        .frame(width: UIScreen.main.bounds.width*0.8)
                    Divider()
                        .frame(width: UIScreen.main.bounds.width*0.8)
                }
                if (isShowSearchResults) {
                    Button(action: {
                        isShowSearchResults = false
                    }, label: {
                        Image(systemName: "plus.circle.fill")
                    })
                    .rotationEffect(.degrees(45))
                }
            }
            if (isShowSearchResults) {
                    ScrollView(.vertical) {
                        VStack {
                            ForEach(0..<briefs.count, id: \.self) {
                                index in
                                RestaurantCellView(restaurantName: briefs[index].restaurantName, district: briefs[index].district, distance: briefs[index].distance, cuisine: briefs[index].cuisine, photos: briefs[index].photos, numOfStars: briefs[index].numOfStars, rating: briefs[index].rating, date: briefs[index].date, time: briefs[index].time)
                                    .onTapGesture {
                                        fetchDiningRoom(roomNumber: briefs[index].roomNumber)
                                        isPresentingFullView = true
                                    }
                                    .fullScreenCover(isPresented: $isPresentingFullView) {
                                        if let diningRoom = rooms {
                                            FullView2(diningRoom: diningRoom, dismissAction: {
                                                isPresentingFullView = false
                                            })
                                            .transition(.move(edge: .leading))
                                        } else {
                                            // You can show a loading view or handle the case when the dining room data is not available yet
                                            Text("Loading...")
                                        }
                                    }
                                Divider()
                            }
                        }
                    }
                
            } else {
                FilterCriteriaRowView()
                Spacer()
                NavigationLink(destination: DiningRoomView(restaurantName: "TeaWood", address: "63 Nathan Rd, Tsim Sha Tsui, Hong Kong", numOfJoined: 3, maxParti: 5, groupDescription: "Welcome all meat lovers! We love to explore restaurants with excellent meat dishes!", roomNumber: "#PR3789", foodPhotos: ["teawood_food_1", "teawood_food_2"], interiorPhotos: ["teawood_interior_1"], menuPhotos: ["teawood_menu_1"]), label: {
                    Image(systemName: "magnifyingglass.circle.fill")
                        .resizable(resizingMode: .stretch)
                        .aspectRatio(1, contentMode: .fit)
                        .frame(height: 40)
                        .foregroundColor(.black)
                    
                })
                .padding()
            }
            
        }
        // custom back button
        .navigationBarBackButtonHidden()
    }
    
    
}

struct SearchingView_Previews: PreviewProvider {
    static var previews: some View {
        SearchingView()
    }
}
