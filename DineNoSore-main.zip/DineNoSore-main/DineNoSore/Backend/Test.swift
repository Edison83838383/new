import Foundation
import SwiftUI

func post() {
    guard let url = URL(string: "https://ap-southeast-1.aws.data.mongodb-api.com/app/data-eatfa/endpoint/data/v1/action/findOne") else {
        print("Invalid URL")
        return
    }
    
    let apiKey = "HZJPHrPLeuDvSaOh7Zug8wdKYmYrspUnQRqrPO7EAVlNPd36TavsT8ds8CmtFKxl"
    let collection = "Collection1"
    let database = "Database1"
    
    // Create the request body as a dictionary
    let requestBody: [String: Any] = [
        "collection": collection,
        "database": database,
        "dataSource": "Cluster0",
        "projection": ["name":"Hello World!"]
    ]
    
    do {
        let jsonData = try JSONSerialization.data(withJSONObject: requestBody)
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("*", forHTTPHeaderField: "Access-Control-Request-Headers")
        request.setValue(apiKey, forHTTPHeaderField: "api-key")
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            if let responseJSON = responseJSON as? [String: Any] {
                print(responseJSON)
            }
        }
        
        task.resume()
    } catch {
        print("Error: \(error)")
    }
    
}

func get() {
    guard let url = URL(string: "http://127.0.0.1:8080/") else {
        print("Invalid URL")
        return
    }
    
    
    let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
        guard let data = data else { return }
        print(String(data: data, encoding: .utf8)!)
    }
    
    task.resume()
    
}

func getChannels(completion: @escaping ([Channel]?) -> Void) {
    guard let url = URL(string: "http://127.0.0.1:8080/channels") else {
        print("Invalid URL")
        completion(nil)
        return
    }
    
    let task = URLSession.shared.dataTask(with: url) { data, response, error in
        guard let data = data else {
            if let error = error {
                print("Error: \(error)")
            }
            completion(nil)
            return
        }
        
        let channels = parseChannels(data: data)
        completion(channels)
    }
    
    task.resume()
}

func parseChannels(data: Data) -> [Channel] {
    var channels: [Channel] = []
    
    do {
        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] {
            for channelJSON in json {
                if let imageName = channelJSON["imageName"] as? String,
                   let restaurantName = channelJSON["restaurantName"] as? String,
                   let date = channelJSON["date"] as? String,
                   let roomNumber = channelJSON["roomNumber"] as? String {
                    
                    let channel = Channel(
                        imageName: imageName,
                        restaurantName: restaurantName,
                        date: date,
                        roomNumber: roomNumber
                    )
                    
                    channels.append(channel)
                }
            }
        }
    } catch {
        print("Error parsing JSON: \(error)")
    }
    return channels
}

func getRestaurantBrief(keyword: String) async -> [RestaurantBrief] {
    let urlString = "http://127.0.0.1:8080/restaurantbrief?keyword=" + keyword
    if let url = URL(string: urlString) {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                if let jsonString = String(data: data, encoding: .utf8) {
                    print(jsonString)
                } else {
                    print("Failed to convert data to string")
                }
                let decoder = JSONDecoder()
                let briefs = try decoder.decode([RestaurantBrief].self, from: data)
                print(briefs)
                print("return here")
                return(briefs)
            } catch {
                print(error)
                return []
            }
    } else {
        print("Invalid URL")
    }
    print("here?")
    return []
}

func getDiningRoom(roomNumber: String) async -> DiningRoom? {
    let urlString = "http://127.0.0.1:8080/diningroom?roomnumber=" + roomNumber
    if let url = URL(string: urlString) {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                if let jsonString = String(data: data, encoding: .utf8) {
                    print(jsonString)
                } else {
                    print("Failed to convert data to string")
                }
                let decoder = JSONDecoder()
                let rooms = try decoder.decode(DiningRoom.self, from: data)
                print(rooms)
                print("return here")
                return(rooms)
            } catch {
                print(error)
                return nil
            }
    } else {
        print("Invalid URL")
    }
    print("here?")
    return nil
}

func getTrending() async -> [RestaurantBrief] {
    let urlString = "http://127.0.0.1:8080/trending"
    if let url = URL(string: urlString) {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                if let jsonString = String(data: data, encoding: .utf8) {
                    print(jsonString)
                } else {
                    print("Failed to convert data to string")
                }
                let decoder = JSONDecoder()
                let briefs = try decoder.decode([RestaurantBrief].self, from: data)
                print(briefs)
                print("return here")
                return(briefs)
            } catch {
                print(error)
                return []
            }
    } else {
        print("Invalid URL")
    }
    print("here?")
    return []
}


struct Test: View {
    var body: some View {
        Button(action: {
            // print("Hello World!")
            //            getChannels { channels in
            //                if let channels = channels {
            //                    print(channels)
            //                } else {
            //                    print("No channels available")
            //                }
            //            }
            
        }, label: {
            /*@START_MENU_TOKEN@*/Text("Button")/*@END_MENU_TOKEN@*/
        })
        .onAppear {
            Task {
                await getDiningRoom(roomNumber: "PR3789")
            }
        }
    }
}

#Preview {
    Test()
}
