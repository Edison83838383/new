//
//  URLImage.swift
//  DineNoSore
//
//  Created by Rain Poon on 6/11/2023.
//

import SwiftUI

struct URLImage: View {
    @State private var imageDatas: [Data?] = []
    
    var body: some View {
        VStack {
            if imageDatas.isEmpty {
                ProgressView()
            } else {
                ScrollView(.vertical) {
                    VStack {
                        ForEach(imageDatas, id: \.self) { imageData in
                            if let data = imageData, let image = UIImage(data: data) {
                                Image(uiImage: image)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            } else {
                                ProgressView()
                            }
                        }
                    }
                }
            }
        }
        .onAppear {
            let urls = [
                URL(string: "https://onedrive.live.com/embed?resid=46CB383393AA6ECC%21378&authkey=%21AMp_CzyBVhiI9n8&width=680&height=510"),
                URL(string: "https://onedrive.live.com/embed?resid=46CB383393AA6ECC%21378&authkey=%21AMp_CzyBVhiI9n8&width=680&height=510"),
                URL(string: "https://onedrive.live.com/embed?resid=46CB383393AA6ECC%21378&authkey=%21AMp_CzyBVhiI9n8&width=680&height=510")
            ]
            loadImages(from: urls)
        }
    }
    
    func loadImages(from urls: [URL?]) {
        for url in urls {
            guard let url = url else { continue }
            
            URLSession.shared.dataTask(with: url) { data, _, error in
                if let error = error {
                    print("Failed to load image: \(error.localizedDescription)")
                    return
                }
                
                if let data = data {
                    DispatchQueue.main.async {
                        // Append the loaded image data to the array
                        imageDatas.append(data)
                    }
                }
            }.resume()
        }
    }
}

#Preview {
    URLImage()
}
