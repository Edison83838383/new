//
//  DineNoSoreApp.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

@main
struct DineNoSoreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
