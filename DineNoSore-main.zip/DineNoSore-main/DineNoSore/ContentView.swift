//
//  ContentView.swift
//  DineNoSore
//
//  Created by Rain Poon on 3/11/2023.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            
            TabView {
                HomePageView()
                    .tabItem {
                        Label("Home", systemImage: "house.fill")
                    }
                ChatChannelsView()
                    .badge(2)
                    .tabItem {
                        Label("Mesages", systemImage: "message.fill")
                    }
                
                UserProfile(profile: Profile.default)
                    .tabItem {
                        Label("Profile", systemImage: "person.fill")
                    }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
